//Include the React library
var React = require('react');

//Include the Router
var Router = require('react-router');
var Route = Router.Route;

//Include the IndexRoute (catch-all route)
var IndexRoute = Router.IndexRoute;

//Reference the components
var Main = require('../components/main');
var Leaderboard = require('../components/children/leaderBoard.js');
var Stats = require('../components/children/MyStats.js');

//Export the Routes
module.exports = (

	/*High level component is the Main Component*/
	//When user goes to root, they will be given the Main component.
<Route path="/" component={Main} >

		{/*If user selects the stats path we get the stats component*/}
		<Route path='/mystats' component={Stats} />

		{/*If user selects leaderboard we get leaderboard component*/}
		<Route path="/leader" component={Leaderboard} />

			{/*If the user selects an alternate path, we get stats*/}
			<IndexRoute component={Stats} />

</Route>

);
