//File handles all routing and is basically the "starting point" for our code/site.
//Include the Main React Dependencies 
var React = require('react');
var ReactDOM = require('react-dom');

//Grab the property associated with the Router
var Router = require('react-router').Router;

//Grab the Routes
var routes = require('./config/routes.js');

//Render our main component aka Parent
ReactDOM.render(
	//routes will tell us where to go depending on the route
	<Router>{routes}</Router>,
	document.getElementById('app')
)