var React = require('react');

/*var Helpers = require('./utils/helpers.js'); */

var Main = React.createClass({
	render:function(){
		return (
			<div>

    			<ul id="dropdown1" className="dropdown-content">
       		 		<li><a style={{fontStyle:'italic',fontSize:'15px',backgroundColor:'rgba(25,118,210,.8)',color:'white'}} href="/users/logout">Log out</a></li>
    			</ul>
    			<div className="navbar-fixed">
    				<nav style={{backgroundColor:'rgba(69,90,100,.8)'}}>
        				<div className="nav-wrapper">
                            <a href="#!" className="brand-logo" style={{marginLeft:'25px',fontFamily:'Halo'}}>HH</a>
                				<ul className="right hide-on-med-and-down">

                    				<li><a href="#/mystats" style={{fontFamily:'Orbitron',fontSize:'12px',letterSpacing:'2px'}}>My Stats</a></li>
                    					<li><a href="#/leader" style={{fontFamily:'Orbitron',fontSize:'12px',letterSpacing:'2px'}}>Leaderboard</a></li>


                    						<li><a className="dropdown-button" href="#!" data-activates="dropdown1"><i className="material-icons right">arrow_drop_down</i></a></li>
             					</ul>
        				</div>
    				</nav>
    			</div>
    			{this.props.children}
			</div>
		)
	}

});

module.exports = Main;
