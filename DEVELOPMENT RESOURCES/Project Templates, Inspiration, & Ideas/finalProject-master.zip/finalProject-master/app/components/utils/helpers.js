var axios = require('axios');

var apiKey = 'aad55617c2e249c39efe825de17622c0';

var Helpers = {
  getLastGames: function(){
    return axios.get('/lastGames').then(function(response){
      return response;
    });
  },
 getSpartan: function() {
      return axios.get('/userSpartan')
        .then(function(response){
        	return response;
        });
    },
 getEmblem: function() {
        return axios.get('/userEmblem')
        .then(function(response){
        	return response;
        });
    },
  getGamertag: function(){
    return axios.get('/gamertag')
    .then(function(response){
      return response;
    });
  },
  postFav: function(gamertag, type, score, kills, deaths, assists, melee, weapon, pound) {
    return axios.post('/saveFav', {gamertag: gamertag, type: type, score: score, kills: kills, deaths: deaths, assists: assists, melee: melee, weapon: weapon, pound: pound}).then(function(result){
      return (result);
    });
  },
  getFav: function(){
    return axios.get('/fav').then(function(response){
      return response;
    });
  },
  getLeaderboard: function() {
    return axios.get('/leaderboard').then(function(response){
      return response;
    });
  }

};
 module.exports = Helpers;
