var React = require('react');
var Helpers = require('../utils/helpers.js');

var MyStats = React.createClass({
	getInitialState: function(){
		return{
			emblem: "",
			spartan:"",
			gamertag:"",
			favGames: [],
			games: []
		}
	},
	getGames: function(){
		var that = this;
		Helpers.getLastGames().then(function(games){
			that.setState({games: games.data});
		})
	},
	saveFav: function(event) {
		var gamertag = event.target.dataset.gamertag;
		var type = event.target.dataset.type;
		var score = event.target.dataset.score;
		var kills = event.target.dataset.kills;
		var deaths = event.target.dataset.deaths;
		var assists = event.target.dataset.asst;
		var melee = event.target.dataset.melee;
		var weapon = event.target.dataset.weapon;
		var pound = event.target.dataset.pound;
		Helpers.postFav(gamertag, type, score, kills, deaths, assists, melee, weapon, pound).then(function(err, res){
			if (err) throw err;
		});
		Materialize.toast('Game Saved', 4000);
		this.getFavs();
	},
	getFavs: function(){
		var that = this;
		Helpers.getFav().then(function(games){
			that.setState({favGames: games.data})
		})
	},

	getEmblem: function(){
		var that = this;
		Helpers.getEmblem().then(function(result){
			that.setState({emblem:result.data})
		})
	},

	getSpartan: function(){
		var that = this;
		Helpers.getSpartan().then(function(result){
			that.setState({spartan:result.data})
		})
	},

	getGamertag: function(){
		var that= this;
		Helpers.getGamertag().then(function(result){
			that.setState({gamertag:result.data})
		})
	},

	componentDidMount: function(){
		this.getEmblem();
		this.getSpartan();
		this.getGamertag();
		this.getFavs();
		this.getGames();
	},

	render: function(){
		var that = this;
		return (
			<div>

			    <div className="row">
			        <div className="col m3"> </div>
			            <div className="col m6 center-align" id="playerProfile" style={{height:'310px',backgroundColor:'rgba(25,118,210,.8)',marginTop:'20px',borderStyle:'solid',borderRadius:'5px',borderColor:'rgba(192,192,192,.4)'}}>
			                <h3 style={{fontFamily:'Halo',fontSize:'40px',color:'rgba(192,192,192,.8)'}}>

			                    <span style={{fontFamily:'Forerunner',paddingRight:'10px',fontSize:'30px'}}>A</span>
			                        Player Info

			                            <span style={{fontFamily:'Forerunner',paddingLeft:'10px',fontSize:'30px'}}>A</span>
			                </h3>

			                <div className="row">
			                    <div className="col m1"> </div>
			                    <div className="col m10" style={{backgroundColor:'rgba(0,0,0,.4)',overflow:'auto',height:'210px'}}>
			                    	<h6 style={{fontFamily:'Halo', fontSize:'25px',color:'rgba(192,192,192,.8)'}}>{this.state.gamertag}</h6>
			                        <img src={this.state.spartan} />
			                        <img src={this.state.emblem} />
			                    </div>
			                    <div className="col m1"> </div>
			                </div>

			            </div>
			        <div className="col m3"> </div>
			    </div>


			    <div className="row">
			        <div className="col m2"> </div>
			            <div className="col m8 center-align" style={{height:'400px',backgroundColor:'rgba(25,118,210,.8)',borderStyle:'solid',borderRadius:'5px',borderColor:'rgba(192,192,192,.4)'}}>
			                <h3 style={{fontFamily:'Halo',fontSize:'40px',color:'rgba(192,192,192,.8)'}}>

			                    <span style={{fontFamily:'Forerunner',paddingRight:'10px',fontSize:'30px'}}>U</span>
			                        My Last Five Games

			                            <span style={{fontFamily:'Forerunner',paddingLeft:'10px',fontSize:'30px'}}>U</span>
			                </h3>

			                <div className="row">
			                    <div className="col m1"> </div>
			                    <div className="col m10" style={{backgroundColor:'rgba(0,0,0,.4)',overflow:'auto',height:'290px'}}>
													<table className="bordered centered responsive-table">
															<thead>
																	<tr style={{borderBottom:'1px solid gray'}}>

															<th style={{color:'rgba(255,255,255,.9',fontFamily:"Orbitron"}} data-field = "last5-type">Type</th>
																			<th style={{color:'rgba(255,255,255,.9',fontFamily:"Orbitron"}} data-field="last5-score">Score</th>
																			<th style={{color:'rgba(255,255,255,.9',fontFamily:"Orbitron"}} data-field="last5-kills">Kills</th>
																			<th style={{color:'rgba(255,255,255,.9',fontFamily:"Orbitron"}} data-field="last5-deaths">Deaths</th>
																			<th style={{color:'rgba(255,255,255,.9',fontFamily:"Orbitron"}} data-field="last5-assists">Assists</th>
																			<th style={{color:'rgba(255,255,255,.9',fontFamily:"Orbitron"}} data-field="last5-melee">Melee Kills</th>
																			<th style={{color:'rgba(255,255,255,.9',fontFamily:"Orbitron"}} data-field="last5-weapon-kills">Weapon Kills</th>
																			<th style={{color:'rgba(255,255,255,.9',fontFamily:"Orbitron"}} data-field="last5-ground-pound">Ground Pound Kills</th>
															<th style={{color:'rgba(255,255,255,.9',fontFamily:"Orbitron"}} data-field = "addToFav">Save Game</th>


																	</tr>
															</thead>
															 <tbody>

															 {this.state.games ? this.state.games.map(function(game, i)
																 {
																	 return (

																		 <tr style={{borderBottom:'1px solid gray'}} key = {i}>
																			 <td style={{color:'silver'}} >{game.type}</td>
																			 <td style={{color:'silver'}} >{game.score}</td>
																			 <td style={{color:'silver'}} >{game.kills}</td>
																			 <td style={{color:'silver'}} >{game.deaths}</td>
																			 <td style={{color:'silver'}} >{game.assists}</td>
																			 <td style={{color:'silver'}} >{game.meleeKills}</td>
																			 <td style={{color:'silver'}} >{game.weaponKills}</td>
																			 <td style={{color:'silver'}} >{game.groundPoundKills}</td>
																			 <td><btn className = "btn-floating btn-small waves-effect waves-light blue-grey"><i className="material-icons" data-gamertag = {game.gamertag} data-type = {game.type} data-score = {game.score} data-kills = {game.kills} data-deaths = {game.deaths} data-asst = {game.assists} data-melee = {game.meleeKills} data-weapon = {game.weaponKills} data-pound = {game.groundPoundKills} onClick = {that.saveFav}>add</i></btn></td>

																		 </tr>
																	 )
																 }
															 ) : (<h3>No Games Found</h3>)
															}
															</tbody>
															</table>
			                        {/* <LastGames /> */}
			                    </div>
			                    <div className="col m1"> </div>
			                </div>

			            </div>
			        <div className="col m2"> </div>
			    </div>


			    <div className="row">
			        <div className="col m2"> </div>
			            <div className="col m8 center-align" style={{height:'400px',backgroundColor:'rgba(25,118,210,.8)',borderStyle:'solid',borderRadius:'5px',borderColor:'rgba(192,192,192,.4)'}}>
			                <h3 style={{fontFamily:'Halo',fontSize:'40px',color:'rgba(192,192,192,.8)'}}>

			                    <span style={{fontFamily:'Forerunner',paddingRight:'10px',fontSize:'30px'}}>O</span>
			                        My Favorite Games

			                            <span style={{fontFamily:'Forerunner',paddingLeft:'10px',fontSize:'30px'}}>O</span>
			                </h3>

			                <div className="row">
			                    <div className="col m1"> </div>
			                    <div className="col m10" style={{backgroundColor:'rgba(0,0,0,.4)',overflow:'auto',height:'290px'}}>
													<table className="bordered centered responsive-table">
																<thead>
																		<tr style={{borderBottom:'1px solid gray'}}>

																<th style={{color:'rgba(255,255,255,.9',fontFamily:"Orbitron"}} data-field ="favgames-type">Type</th>
																				<th style={{color:'rgba(255,255,255,.9',fontFamily:"Orbitron"}} data-field="favgames-score">Score</th>
																				<th style={{color:'rgba(255,255,255,.9',fontFamily:"Orbitron"}} data-field="favgames-kills">Kills</th>
																				<th style={{color:'rgba(255,255,255,.9',fontFamily:"Orbitron"}} data-field="favgames-deaths">Deaths</th>
																				<th style={{color:'rgba(255,255,255,.9',fontFamily:"Orbitron"}} data-field="favgames-assists">Assists</th>
																				<th style={{color:'rgba(255,255,255,.9',fontFamily:"Orbitron"}} data-field="favgames-melee">Melee Kills</th>
																				<th style={{color:'rgba(255,255,255,.9',fontFamily:"Orbitron"}} data-field="favgames-weapon-kills">Weapon Kills</th>
																				<th style={{color:'rgba(255,255,255,.9',fontFamily:"Orbitron"}} data-field="favgames-ground-pound">Ground Pound Kills</th>

																		</tr>
																</thead>
																 <tbody>
																 {this.state.favGames ? this.state.favGames.map(function(game, i)
																	{
																		return (
																			<tr style={{borderBottom:'1px solid gray'}} key = {i}>
																				<td style={{color:'silver'}} >{game.type}</td>
																				<td style={{color:'silver'}} >{game.score}</td>
																				<td style={{color:'silver'}} >{game.kills}</td>
																				<td style={{color:'silver'}} >{game.deaths}</td>
																				<td style={{color:'silver'}} >{game.assists}</td>
																				<td style={{color:'silver'}} >{game.meleeKills}</td>
																				<td style={{color:'silver'}} >{game.weaponKills}</td>
																				<td style={{color:'silver'}} >{game.groundPoundKills}</td>
																			</tr>
																		)
																	}
																) : (<h3>No Favorite Games Yet</h3>)
																}
																</tbody>
																</table>
			                        {/* <FavGames /> */}
			                    </div>
			                    <div className="col m1"> </div>
			                </div>

			        </div>
			        <div className="col m2"> </div>
			    </div>

			</div>
		)
	}
});

module.exports = MyStats;
