var React = require('react');
var Helpers = require('../utils/helpers.js');
var LeaderBoard = React.createClass({
  getInitialState: function() {
    return {
      leaderboard: []
    };
  },
  componentDidMount: function(){
    this.getLeaderboard();
  },
  getLeaderboard: function(){
    var that = this;
    Helpers.getLeaderboard().then(function(scores){
      that.setState({leaderboard: scores.data});
    });
  },
  render: function() {
    return (
      <div className="row">
          <div className="col m1"></div>
              <div className="col m10 center-align" style={{height:'400px',backgroundColor:'rgba(25,118,210,.8)',borderStyle:'solid',borderRadius:'5px',borderColor:'rgba(192,192,192,.4)',marginTop:'20px'}}>
                  <h3 style={{fontFamily:'Halo',fontSize:'40px',color:'rgba(192,192,192,.8)'}}>

                      <span style={{fontFamily:'Forerunner',paddingRight:'10px',fontSize:'30px'}}>O</span>
                          Leaderboard

                              <span style={{fontFamily:'Forerunner',paddingLeft:'10px',fontSize:'30px'}}>O</span>
                  </h3>

                  <div className="row">
                      <div className="col m12" style={{backgroundColor:'rgba(0,0,0,.4)',overflow:'auto',height:'290px'}}>
                      <table className="bordered centered responsive-table">
                            <thead>
                                <tr style={{borderBottom:'1px solid gray'}}>
                                    <th style={{color:'rgba(255,255,255,.9'}} >Gamertag</th>
                                    <th style={{color:'rgba(255,255,255,.9', fontFamily:"Orbitron"}} data-field ="favgames-type">Type</th>
                                    <th style={{color:'rgba(255,255,255,.9',fontFamily:"Orbitron"}} data-field="favgames-score">Score</th>
                                    <th style={{color:'rgba(255,255,255,.9',fontFamily:"Orbitron"}} data-field="favgames-kills">Kills</th>
                                    <th style={{color:'rgba(255,255,255,.9',fontFamily:"Orbitron"}} data-field="favgames-deaths">Deaths</th>
                                    <th style={{color:'rgba(255,255,255,.9',fontFamily:"Orbitron"}} data-field="favgames-assists">Assists</th>
                                    <th style={{color:'rgba(255,255,255,.9',fontFamily:"Orbitron"}} data-field="favgames-melee">Melee Kills</th>
                                    <th style={{color:'rgba(255,255,255,.9',fontFamily:"Orbitron"}} data-field="favgames-weapon-kills">Weapon Kills</th>
                                    <th style={{color:'rgba(255,255,255,.9',fontFamily:"Orbitron"}} data-field="favgames-ground-pound">Ground Pound Kills</th>
                                </tr>
                            </thead>
                             <tbody>
                             {this.state.leaderboard ? this.state.leaderboard.map(function(game, i)
                              {
                                return (
                                  <tr style={{borderBottom:'1px solid gray'}} key = {i}>
                                    <td style={{color:'silver'}} >{game.gamertag}</td>
                                    <td style={{color:'silver'}} >{game.type}</td>
                                    <td style={{color:'silver'}} >{game.score}</td>
                                    <td style={{color:'silver'}} >{game.kills}</td>
                                    <td style={{color:'silver'}} >{game.deaths}</td>
                                    <td style={{color:'silver'}} >{game.assists}</td>
                                    <td style={{color:'silver'}} >{game.meleeKills}</td>
                                    <td style={{color:'silver'}} >{game.weaponKills}</td>
                                    <td style={{color:'silver'}} >{game.groundPoundKills}</td>
                                  </tr>
                                )
                              }
                            ) : (<tr><td>No games in leaderboard</td></tr>)
                            }
                            </tbody>
                          </table>
                      </div>
                  </div>

          </div>
          <div className="col m1"> </div>
      </div>
    );
  }
});

module.exports = LeaderBoard;
