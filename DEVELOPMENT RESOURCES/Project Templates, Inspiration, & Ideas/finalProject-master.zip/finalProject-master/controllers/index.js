var express = require('express');
var router = express.Router();
var request = require('request');
var path = require('path');
var rp = require('request-promise');

var Fav = require('../models/favs.js');


// Get Homepage
router.get('/', ensureAuthenticated, function(req, res){
	if(req.user){
	res.sendFile(path.join(__dirname, '../public', 'index.html'));
} else {
	res.sendStatus(401);
}
});

function ensureAuthenticated(req, res, next){
	if(req.isAuthenticated()){
		return next();
	} else {
		res.redirect('/users/login');
	}
}

//Get users gamertag route
router.get('/gamertag', function(req,res){
    res.send(req.user.gamerTag);
});

//Get emblem image route
router.get('/userEmblem', function(req,res){
	//send a request to the halo waypoint api for the emblem image
	request({
		headers: {
			'Ocp-Apim-Subscription-Key': 'aad55617c2e249c39efe825de17622c0',
		},
		uri: "https://www.haloapi.com/profile/h5/profiles/"+req.user.gamerTag+"/emblem?size=128",
		method: 'GET'
	}, function(err, response, body){
		//if there's an error then throw it
		if (err) throw err;
		//else respond the href of the emblem image
		res.json(response.request.uri.href);
	});

});

router.get('/gamertag', function(req,res){
	res.send(req.user.gamerTag);
});

//Get spartan image route
router.get('/userSpartan', function(req,res){
	//send a request to the halo waypoint api for the emblem image
	request({
		headers: {
			'Ocp-Apim-Subscription-Key': 'aad55617c2e249c39efe825de17622c0',
		},
		uri: "https://www.haloapi.com/profile/h5/profiles/"+req.user.gamerTag+"/spartan?size=128",
		method: 'GET'
	}, function(err, response, body){
		//if there's an error then throw it
		if (err) throw err;
		//else respond the href of the spartan image
		res.json(response.request.uri.href);
	});
});

//Get users last games route ***still needs work***
router.get('/lastGames', function(req,res){
	//first send a request to the halo waypoint api for the match id's of the players last 5 games
	request({
    headers: {
      'Ocp-Apim-Subscription-Key': 'aad55617c2e249c39efe825de17622c0',
    },
    uri: "https://www.haloapi.com/stats/h5/players/"+ req.user.gamerTag + "/matches?modes=arena%2Cwarzone&count=5",
    method: 'GET'
  }, function (err, response, body) {
        //if there's an error then throw it
    if(err) return res.json(err);
        //create an empty array to later hold all of the match id's
        var matchRequests = [];
        //turn the response body string into a JSON object
        var matchObj = JSON.parse(body);
        //loop through the object's Results array
        for(var i = 0; i < matchObj.Results.length; i++){
            var type = matchObj.Results[i].Id.GameMode === 1 ? "arena" : "warzone";
            var config = {
                    headers: {
                        'Ocp-Apim-Subscription-Key': 'aad55617c2e249c39efe825de17622c0',
                    },
                    uri: "https://www.haloapi.com/stats/h5/"+type+"/matches/"+matchObj.Results[i].Id.MatchId,
                    method: 'GET'
            };
            matchRequests.push(rp(config));
        }


        Promise.all(matchRequests).then(function(results){
            //res.json(results.length);
            var myMatchStats = [];
            results.forEach(function(object){

                var parsed = JSON.parse(object);

                parsed.PlayerStats.forEach(function(player){
                    if(player.Player.Gamertag == req.user.gamerTag) {
                        var game = {
														gamertag: req.user.gamerTag,
                            type: player.WarzoneLevel ? 'Warzone' : 'Arena',
                            score: player.XpInfo.TotalXP - player.XpInfo.PrevTotalXP,
                            kills: player.TotalKills,
                            deaths: player.TotalDeaths,
                            assists: player.TotalAssists,
                            meleeKills: player.TotalMeleeKills,
                            weaponKills: player.TotalPowerWeaponKills,
                            headshots: player.TotalHeadshots,
                            assassinations: player.TotalAssassinations,
                            groundPoundKills: player.TotalGroundPoundKills
                        };
                        myMatchStats.push(game);
                    }
                });
            });
            return res.json(myMatchStats);

        });

    });
});

router.post('/saveFav', function(req,res){
  Fav.create({type: req.body.type, gamertag: req.body.gamertag, score: req.body.score, kills: req.body.kills, deaths: req.body.deaths, assists: req.body.assists, meleeKills: req.body.melee, weaponKills: req.body.weapon, groundPoundKills: req.body.pound});
});

router.get('/fav', function(req,res){
	Fav.find({gamertag: req.user.gamerTag}).sort({kills: -1}).exec(function(err, doc){
    if (err) throw err;
    res.send(doc);
  });
});

router.get('/leaderboard', function(req,res){
	Fav.find({}).sort({kills: -1}).exec(function(err,doc){
		if (err) console.log(err);
		res.json(doc);
	});
});

module.exports = router;
