//===================================================
// ##################Dependencies####################
//===================================================
var express = require('express');
var router = express.Router();
var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;

//Bring in the models
var User = require('../models/userSchema.js');

//===================================================
//####################Routes#########################
//===================================================
router.get('/login', function(req,res){
  res.render('login');
});


router.post('/signup', function(req,res){
  var newUser = {
    gamerTag: req.body.gamerTag,
    password: req.body.password,
    email: req.body.email,
    firstName: req.body.firstName,
    lastName: req.body.lastName,
  };
  User.createUser(newUser, function(err, user){
    if(err) {
      res.send(err);
    } else {
      res.redirect('/');
    }
  });
});

passport.use(new LocalStrategy(
  function(gamerTag, password, done) {
    User.getUserByUsername(gamerTag, function(err, user){
      if (err) throw err;
      if(!user){
        return done(null,false);
      }
      User.comparePassword(password, user.password, function(err, match){
        if (err) throw err;
        if(match) {
          return done(null, user);
        } else {
          return done(null, false);
        }
      });
    });
  }
));

passport.serializeUser(function(user,done){
  done(null, user.id);
});

passport.deserializeUser(function(id, done){
  User.getUserById(id, function(err, user){
    done(err, user);
  });
});



router.post('/signin', passport.authenticate('local', {successRedirect: '/',failureFlash: true}), function(req,res){
  res.send('userName');
});

router.get('/failure', function(req,res){
  res.sendStatus(401);
});

router.get('/logout', function(req, res){
	req.logout();

	req.flash('success_msg', 'You are logged out');

	res.redirect('/users/login');
});

module.exports = router;
