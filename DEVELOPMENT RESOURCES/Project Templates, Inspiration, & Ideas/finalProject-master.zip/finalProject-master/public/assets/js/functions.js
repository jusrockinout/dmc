$(document).ready(function(){
   $('.modal-trigger').leanModal({
      dismissible: true, // Modal can be dismissed by clicking outside of the modal
      opacity: 0.5, // Opacity of modal background
      in_duration: 300, // Transition in duration
      out_duration: 200, // Transition out duration
    }
  );

  $(".dropdown-button").dropdown();


//NOTE: Not sure if we need this or not. It's mainly the same code from the Eatinerary app.
 var currentURL = window.location.origin;

  $('#signUp').on('click', function(e){
    e.preventDefault();
    var newUser = {
      firstName: $('#first_name').val().trim(),
      lastName: $('#last_name').val().trim(),
      gamerTag: $('#gamertag').val().trim(),
      password: $('#password').val().trim(),
      reenterpassword: $('#reenterpassword').val().trim(),
      email: $('#email').val().trim()
    };
    if(newUser.password === newUser.reenterpassword){
    $.post(currentURL + "/users/signup", newUser ,function(err){
      console.log(err);
      if (err == "alert"){
        sweetAlert("Oops...", "Username is taken, try another!", "error");
      }
      else {
        var currentURL = window.location.origin;
        console.log('success');
        sweetAlert({title:"You're now signed up",text: "Thanks for joining Halo Hierarchy",type: "success",showCancelButton: false,   confirmButtonColor: "#2ecc71", confirmButtonText: "Return to login ", closeOnConfirm: true }, function(){
          $('#signup').closeModal();
          //window.location.replace(currentURL);
        });

      }
    });
  }
  else {
    sweetAlert("Oops...", "Please make sure your passwords match!", "error");
  }
    return false;
  });

 $('#signInSubmit').on('click', function(e){
   e.preventDefault();
   var userInfo = {
    username: $('#signInUser').val().trim(),
    password: $('#signInPass').val().trim()
    };
   var currentURL = window.location.origin;
   $.post(currentURL + '/users/signin', userInfo, function(data){
    if (!data){
      console.log(data);
      sweetAlert("Oops...", "Wrong username or password!", "error");
    }
    else {
      window.location.replace(currentURL);
    }
   });
  }); //closes out submit button on click
 //Closes out document.ready!
});
