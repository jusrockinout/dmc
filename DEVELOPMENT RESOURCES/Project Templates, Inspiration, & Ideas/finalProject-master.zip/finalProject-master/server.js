//======================================================
//####################Dependencies######################
//======================================================
var express = require('express');
var path = require('path');
var bodyParser = require('body-parser');
var app = express();
var methodOverride = require('method-override');
var session = require('express-session');
var cookieParser = require('cookie-parser');
var passport = require('passport');
var mongoose = require('mongoose');
var exphbs = require('express-handlebars');
var flash = require('connect-flash');

//===================================================
// #######Database configuration with mongoose#######
//===================================================
mongoose.connect('mongodb://localhost/haloApp');
var db = mongoose.connection;

// show any mongoose errors
db.on('error', function(err) {
  console.log('Mongoose Error: ', err);
});

// once logged in to the db through mongoose, log a success message
db.once('open', function() {
  console.log('Mongoose connection successful.');
});

//=====================================================
//###################Configurations####################
//=====================================================

app.use(bodyParser.urlencoded({
	extended: false
}));
app.use(bodyParser.json());
app.use(bodyParser.text());
app.use(bodyParser.json({type:'application/vnd.api+json'}));

app.use(cookieParser());

//Express session setup
app.use(session({
  secret: 'secret',
  saveUninitialized: true,
  resave: true
}));

//Handlebars configuration
app.set('views', path.join(__dirname, 'views'));
app.engine('handlebars', exphbs({
    defaultLayout: 'main'
}));
app.set('view engine', 'handlebars');

//Passport init
app.use(passport.initialize());
app.use(passport.session());
app.use(flash());

// override with POST having ?_method=DELETE
app.use(methodOverride('_method'));

app.use(function (req, res, next) {
  res.locals.user = req.user || null;
  next();
});


var routes = require('./controllers/index.js');
var login = require('./controllers/login.js');
app.use('/', routes);
app.use('/users', login);
app.use('/static', express.static(__dirname + '/public'));
//Tell the app to listen on port 5000.
var PORT = process.env.PORT || 5000;
app.listen(PORT, function(){
  console.log("listening on port: "+ PORT);
});
