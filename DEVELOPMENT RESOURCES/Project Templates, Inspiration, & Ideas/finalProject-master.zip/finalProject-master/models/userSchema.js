var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var bcrypt = require('bcryptjs');

var UserSchema = new Schema({
  gamerTag: {
    type: String,
    required: true,
    unique: true,
    dropDups: true
  },
  password: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true
  },
  firstName: {
    type: String
  },
  lastName: {
    type: String
  },

  topGames: {
      type: Schema.Types.ObjectId,
      ref: 'topGames'
  }
});

var User = module.exports = mongoose.model('User', UserSchema);

module.exports.createUser = function(newUser, callback){
  bcrypt.genSalt(10,function(err,salt){
    bcrypt.hash(newUser.password, salt, function(err,hash){
      newUser.password = hash;
      console.log('bcrypt hit');
      User.create(newUser, callback);
    });
  });
};

module.exports.getUserByUsername = function(gamerTag, cb){
  var query = {gamerTag: gamerTag};
  User.findOne(query, cb);
};

module.exports.getUserById = function(id, cb){
  User.findById(id, cb);
};

module.exports.comparePassword = function(candidatePassword, hash, cb) {
  bcrypt.compare(candidatePassword, hash, function(err, res){
    if (err) throw err;
    cb(null, res);
  });
};
