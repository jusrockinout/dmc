//Dependency
var mongoose = require("mongoose");

//Create the Schema class
var Schema = mongoose.Schema;

//Instantiate a leaderSchema object with the Schema class we just made
var favSchema = new Schema({
  type: {
    type: String
  },
  gamertag: {
    type: String
  },
	score: {
		type:Number
	},
	kills: {
		type:Number
	},
	deaths: {
		type:Number
	},
	assists: {
		type:Number
	},
	meleeKills: {
		type:Number
	},
	weaponKills: {
		type:Number
	},
	groundPoundKills: {
		type:Number
	}

});

//Create the leader model with our leaderSchema
var Fav = mongoose.model('Fav', favSchema);

//Export the Leader model, so it can be used elsewhere
module.exports = Fav;
