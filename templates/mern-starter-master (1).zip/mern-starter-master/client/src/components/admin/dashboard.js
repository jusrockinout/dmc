import React, { Component } from 'react';
import { Link } from 'react-router';

class AdminDashboard extends Component {
  render() {
    return (
      <div>
        Admin navigation goes here.
      </div>
    );
  }
}

export default AdminDashboard;
