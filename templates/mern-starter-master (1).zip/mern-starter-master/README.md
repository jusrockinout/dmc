# MERN Starter
Starter/seed project for MongoDB, Express, React, Node full-stack JavaScript apps.

## TODO
- Finish user profile pages (edit, view profile, etc.)

## Longer-term Goals
- Social login integration

## Contributions
Please feel free to contribute to this project. Whether it's features, tests, or code cleanup, any help is welcome at this point.

Relevant tutorials found at https://blog.slatepeak.com
